
import requests
import json
import urllib3

from requests.auth import HTTPBasicAuth  # for Basic Auth

from urllib3.exceptions import InsecureRequestWarning  # for insecure https warnings

urllib3.disable_warnings(InsecureRequestWarning)  # disable insecure https warnings

from config import WEBHOOK_URL, WEBHOOK_USERNAME, WEBHOOK_PASSWORD


# set the payload for a Infobip sample notification event notification

payload = {
    "channel": "LIVE_CHAT",
    "content": {
        "showUrlPreview": "null",
        "text": "Hi"
    },
    "contentType": "TEXT",
    "conversationId": "1daf101d-53bc-4b7a-8da7- 53e88ca4a291",
    "createdAt": "2023-12-05T17:54:16.951+00:00",
    "direction": "INBOUND",
    "from": "5541991440444",
    "id": "adb216f5-c540-45c9-94da-433c6d05de06",
    "singleSendMessage": {
        "channel": "LIVE_CHAT",
        "contact": {
            "name": "Alexandre Gouveia"
        },
        "content": {
            "context": "null",
            "referral": "null",
            "text": "Hi",
            "type": "TEXT"
        },
        "direction": "INBOUND",
        "from": {
            "id": "237846237846112376123",
            "type": "ID"
        },
        "identity": "null",
        "to": {
            "phoneNumber": "237846237846112376123",
            "type": "ID"
        }
    },
    "to": "239847234723746y23784623",
    "updatedAt": "2023-12-05T17:54:16.951+00:00"
}






# test the Webhook with a Infobip sample notification

basic_auth = HTTPBasicAuth(WEBHOOK_USERNAME, WEBHOOK_PASSWORD)

url = "https://127.0.0.1:8000/webhook"
header = {'content-type': 'application/json'}
response = requests.post(url, auth=basic_auth, data=json.dumps(payload), headers=header, verify=False)
print('\nWebhook notification status code: ', response.status_code)
print('\nWebhook notification response: ', response.text)